#include <stdlib.h>

void hisn( float *his, unsigned char *buf, long size) {



}
