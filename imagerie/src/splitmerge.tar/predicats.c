#include "splitmerge.h"

/* tme 8 */
int predsplit( region *r, float threshold) {

  /* à compléter pour répondre à la question 1.1 */


} 

/* tme 9 */
int predmerge( region *a, region *b, float thresh) {

  /* à compléter pour répondre à la question 2.1  */

}
